package sax.parser;

/**
 *
 * @author alexr
 */
public class Geraete {
    private String schuhe;
    private String weiteres;

    public String getSchuhe() {
        return schuhe;
    }

    public void setSchuhe(String schuhe) {
        this.schuhe = schuhe;
    }

    public String getWeiteres() {
        return weiteres;
    }

    public void setWeiteres(String weiteres) {
        this.weiteres = weiteres;
    }
}
